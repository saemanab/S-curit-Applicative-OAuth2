# AP4 - Sécurité Applicative : OAuth2 / OIDC / JWT / Keycloak

Projet complet pour l'Activité Pratique N°4.

## Structure du projet

```
ap4-keycloak/
├── keycloak-config/
│   ├── ebank-realm-export.json     # Configuration Keycloak à importer
│   └── postman-collection.json     # Tests Postman (importer dans Postman)
│
├── ebank-backend/                  # Spring Boot 3 - Resource Server
│   ├── pom.xml
│   └── src/main/java/com/ebank/
│       ├── EbankBackendApplication.java
│       ├── config/
│       │   ├── SecurityConfig.java          # Config Spring Security + JWT
│       │   └── KeycloakRoleConverter.java   # Conversion rôles Keycloak → Spring
│       ├── controller/
│       │   ├── PublicController.java        # Endpoints publics (pas de token)
│       │   ├── BankAccountController.java   # Endpoints USER/ADMIN
│       │   └── AdminController.java         # Endpoints ADMIN only
│       ├── entity/
│       │   ├── Customer.java
│       │   └── BankAccount.java
│       ├── repository/
│       ├── service/
│       └── dto/
│
└── ebank-frontend/                 # Angular 16 - Client OIDC
    └── src/app/
        ├── app.module.ts                    # Init Keycloak (APP_INITIALIZER)
        ├── app-routing.module.ts            # Routes protégées par AuthGuard
        ├── guards/auth.guard.ts             # Keycloak AuthGuard
        ├── interceptors/auth.interceptor.ts # Ajout Bearer token automatique
        ├── services/
        │   ├── auth.service.ts              # Wrapper KeycloakService
        │   └── bank-account.service.ts      # Appels API backend
        ├── models/models.ts
        └── components/
            ├── navbar/     # Affiche user, roles, logout
            ├── accounts/   # Liste des comptes (USER)
            ├── admin/      # Tableau admin (ADMIN only)
            └── login/      # Page accès refusé
```

---

## Partie 1 : Configuration Keycloak

### 1. Démarrer Keycloak 19

```bash
# Télécharger depuis https://github.com/keycloak/keycloak/releases/tag/19.0.3
unzip keycloak-19.0.3.zip
cd keycloak-19.0.3

# Démarrer en mode développement
bin/kc.sh start-dev          # Linux/macOS
bin\kc.bat start-dev         # Windows
```

Keycloak démarre sur **http://localhost:8080**

### 2. Importer le Realm (méthode rapide)

```bash
bin/kc.sh import --file ../keycloak-config/ebank-realm-export.json
```

Ou manuellement via l'interface admin (voir étapes ci-dessous).

### 3. Configuration manuelle

1. Aller sur http://localhost:8080 → Créer admin (admin / admin123)
2. **Créer Realm** : "ebank-realm"
3. **Créer Client** :
   - Client ID : `ebank-client`
   - Client authentication : ON
   - Valid redirect URIs : `http://localhost:4200/*`
   - Web origins : `http://localhost:4200`
4. **Créer Rôles** : `USER` et `ADMIN` (Realm roles)
5. **Créer Utilisateurs** :
   - `user1` / password: `1234` → rôle: USER
   - `admin1` / password: `admin123` → rôles: USER + ADMIN
6. **Récupérer le Client Secret** : Clients → ebank-client → Credentials

---

## Partie 2 : Spring Boot Backend

### Démarrage

```bash
cd ebank-backend
mvn spring-boot:run
```

Backend disponible sur **http://localhost:8085**

### Endpoints

| Méthode | URL | Rôle requis |
|---------|-----|-------------|
| GET | /api/public/info | Aucun |
| GET | /api/accounts | USER ou ADMIN |
| GET | /api/accounts/{id} | USER ou ADMIN |
| GET | /api/profile | Authentifié |
| GET | /api/token-info | Authentifié |
| GET | /api/admin/accounts | ADMIN |
| GET | /api/admin/dashboard | ADMIN |

### Console H2 (base de données en mémoire)

http://localhost:8085/h2-console  
JDBC URL: `jdbc:h2:mem:ebankdb`

---

## Partie 3 : Angular Frontend

### Installation et démarrage

```bash
cd ebank-frontend
npm install
ng serve
```

Frontend disponible sur **http://localhost:4200**

---

## Tests Postman

1. Ouvrir Postman
2. **Importer** le fichier `keycloak-config/postman-collection.json`
3. Mettre à jour la variable `client_secret` avec votre secret Keycloak
4. Exécuter les requêtes dans l'ordre :
   - Requête 1 → Authentification password (remplit auto access_token et refresh_token)
   - Requête 2 → Test refresh token
   - Requête 3 → Client credentials (M2M)
   - Requête 7/8/9 → Tests des endpoints API

### Analyser un JWT

Copier la valeur du `access_token` et la coller sur https://jwt.io

---

## Points clés OAuth2/OIDC/JWT

| Concept | Description |
|---------|-------------|
| **Access Token** | JWT court (5-15 min) contenant les rôles. Envoyé dans `Authorization: Bearer` |
| **Refresh Token** | JWT long (30 min+). Utilisé pour renouveler l'access token |
| **ID Token** | JWT OIDC avec infos utilisateur. Pour le frontend uniquement |
| **JWKS** | Clés publiques RSA de Keycloak pour valider la signature JWT |
| **realm_access.roles** | Claim JWT contenant les rôles de l'utilisateur |
