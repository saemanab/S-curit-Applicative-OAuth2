import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="page">
      <div class="card">
        <div class="icon">🔒</div>
        <h2>Accès Non Autorisé</h2>
        <p>Vous n'avez pas les droits suffisants pour accéder à cette page.</p>
        <p class="hint">Connectez-vous avec un compte ayant les rôles requis.</p>
        <button (click)="login()" class="btn">Se connecter avec Keycloak</button>
      </div>
    </div>
  `,
  styles: [`
    .page { display: flex; justify-content: center; align-items: center; height: 80vh; }
    .card { text-align: center; padding: 48px; background: white; border-radius: 12px; box-shadow: 0 4px 16px rgba(0,0,0,0.1); }
    .icon { font-size: 64px; margin-bottom: 16px; }
    h2 { color: #1F4E79; }
    p { color: #666; }
    .hint { font-size: 13px; color: #999; }
    .btn { margin-top: 20px; padding: 12px 24px; background: #2E75B6; color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 15px; }
    .btn:hover { background: #1F4E79; }
  `]
})
export class LoginComponent {
  constructor(private authService: AuthService) {}
  login(): void { this.authService.login(); }
}
