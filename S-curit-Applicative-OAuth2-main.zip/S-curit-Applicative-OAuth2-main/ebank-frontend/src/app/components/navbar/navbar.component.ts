import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <nav class="navbar">
      <div class="navbar-brand">
        <span class="logo">🏦 E-Bank</span>
      </div>

      <div class="navbar-menu">
        <a routerLink="/accounts" routerLinkActive="active">Mes Comptes</a>
        <a *ngIf="isAdmin" routerLink="/admin" routerLinkActive="active">Administration</a>
      </div>

      <div class="navbar-user" *ngIf="isLoggedIn">
        <span class="user-info">
          👤 {{ username }}
          <span class="role-badge" *ngFor="let role of roles">{{ role }}</span>
        </span>
        <button (click)="manageAccount()" class="btn-secondary">Mon Compte</button>
        <button (click)="logout()" class="btn-danger">Déconnexion</button>
      </div>

      <div class="navbar-user" *ngIf="!isLoggedIn">
        <button (click)="login()" class="btn-primary">Connexion</button>
      </div>
    </nav>
  `,
  styles: [`
    .navbar {
      display: flex; align-items: center; padding: 12px 24px;
      background: #1F4E79; color: white; gap: 16px;
    }
    .logo { font-size: 20px; font-weight: bold; }
    .navbar-menu { display: flex; gap: 16px; flex: 1; margin-left: 32px; }
    .navbar-menu a { color: #cce; text-decoration: none; padding: 6px 12px; border-radius: 4px; }
    .navbar-menu a.active, .navbar-menu a:hover { background: rgba(255,255,255,0.2); color: white; }
    .navbar-user { display: flex; align-items: center; gap: 8px; }
    .user-info { display: flex; align-items: center; gap: 6px; }
    .role-badge { background: #2E75B6; padding: 2px 8px; border-radius: 12px; font-size: 11px; }
    button { padding: 6px 14px; border: none; border-radius: 4px; cursor: pointer; font-size: 13px; }
    .btn-primary { background: #2E75B6; color: white; }
    .btn-secondary { background: rgba(255,255,255,0.2); color: white; }
    .btn-danger { background: #C0392B; color: white; }
  `]
})
export class NavbarComponent implements OnInit {

  isLoggedIn = false;
  isAdmin = false;
  username = '';
  roles: string[] = [];

  constructor(private authService: AuthService) {}

  ngOnInit(): void {
    this.isLoggedIn = this.authService.isLoggedIn();
    if (this.isLoggedIn) {
      this.username = this.authService.getUsername();
      this.roles = this.authService.getUserRoles()
        .filter(r => ['USER', 'ADMIN'].includes(r));
      this.isAdmin = this.authService.isAdmin();
    }
  }

  login(): void { this.authService.login(); }
  logout(): void { this.authService.logout(); }
  manageAccount(): void { this.authService.manageAccount(); }
}
