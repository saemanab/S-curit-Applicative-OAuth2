import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BankAccountService } from '../../services/bank-account.service';
import { BankAccount } from '../../models/models';

@Component({
  selector: 'app-admin',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="container">
      <div class="admin-header">
        <h2>🛡️ Panneau d'Administration</h2>
        <span class="admin-badge">ADMIN</span>
      </div>

      <div class="loading" *ngIf="loading">Chargement de tous les comptes...</div>
      <div class="error" *ngIf="error">{{ error }}</div>

      <table class="accounts-table" *ngIf="!loading && accounts.length > 0">
        <thead>
          <tr>
            <th>N° Compte</th>
            <th>Client</th>
            <th>Solde</th>
            <th>Devise</th>
            <th>Date création</th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let account of accounts">
            <td><strong>{{ account.accountNumber }}</strong></td>
            <td>{{ account.customerName }}</td>
            <td class="balance">{{ account.balance | number:'1.2-2' }}</td>
            <td>{{ account.currency }}</td>
            <td>{{ account.createdAt | date:'dd/MM/yyyy' }}</td>
          </tr>
        </tbody>
      </table>

      <div class="summary" *ngIf="!loading && accounts.length > 0">
        <strong>Total comptes :</strong> {{ accounts.length }} |
        <strong>Total solde :</strong> {{ totalBalance | number:'1.2-2' }} MAD
      </div>
    </div>
  `,
  styles: [`
    .container { padding: 24px; max-width: 1100px; margin: 0 auto; }
    .admin-header { display: flex; align-items: center; gap: 12px; margin-bottom: 24px; }
    .admin-header h2 { color: #1F4E79; margin: 0; }
    .admin-badge { background: #C0392B; color: white; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: bold; }
    .accounts-table { width: 100%; border-collapse: collapse; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
    .accounts-table th { background: #1F4E79; color: white; padding: 12px 16px; text-align: left; font-size: 13px; }
    .accounts-table td { padding: 10px 16px; border-bottom: 1px solid #eee; font-size: 14px; }
    .accounts-table tr:hover td { background: #EBF5FB; }
    .balance { font-weight: bold; color: #1E7E34; }
    .summary { margin-top: 16px; padding: 12px; background: #EBF5FB; border-radius: 4px; color: #1F4E79; }
    .loading { text-align: center; padding: 40px; color: #666; }
    .error { color: #C0392B; background: #FDECEA; padding: 12px; border-radius: 4px; }
  `]
})
export class AdminComponent implements OnInit {

  accounts: BankAccount[] = [];
  loading = true;
  error = '';

  get totalBalance(): number {
    return this.accounts.reduce((sum, a) => sum + a.balance, 0);
  }

  constructor(private accountService: BankAccountService) {}

  ngOnInit(): void {
    this.accountService.getAllAccounts().subscribe({
      next: (accounts) => {
        this.accounts = accounts;
        this.loading = false;
      },
      error: (err) => {
        this.error = 'Accès refusé ou erreur serveur.';
        this.loading = false;
        console.error(err);
      }
    });
  }
}
