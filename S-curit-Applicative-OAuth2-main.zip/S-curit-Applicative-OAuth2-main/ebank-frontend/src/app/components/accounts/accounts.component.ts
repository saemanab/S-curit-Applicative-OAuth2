import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BankAccountService } from '../../services/bank-account.service';
import { AuthService } from '../../services/auth.service';
import { BankAccount, UserProfile } from '../../models/models';

@Component({
  selector: 'app-accounts',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="container">
      <div class="profile-card" *ngIf="profile">
        <h2>👤 Mon Profil</h2>
        <div class="profile-grid">
          <div><strong>Nom :</strong> {{ profile.firstName }} {{ profile.lastName }}</div>
          <div><strong>Email :</strong> {{ profile.email }}</div>
          <div><strong>Username :</strong> {{ profile.username }}</div>
          <div>
            <strong>Rôles :</strong>
            <span class="badge" *ngFor="let role of profile.roles">{{ role }}</span>
          </div>
        </div>
      </div>

      <div class="accounts-section">
        <h2>💳 Mes Comptes Bancaires</h2>

        <div class="loading" *ngIf="loading">Chargement...</div>
        <div class="error" *ngIf="error">{{ error }}</div>

        <div class="accounts-grid" *ngIf="!loading && accounts.length > 0">
          <div class="account-card" *ngFor="let account of accounts">
            <div class="account-header">
              <span class="account-number">{{ account.accountNumber }}</span>
              <span class="currency">{{ account.currency }}</span>
            </div>
            <div class="balance">{{ account.balance | number:'1.2-2' }} {{ account.currency }}</div>
            <div class="customer-name">{{ account.customerName }}</div>
            <div class="created-at">Ouvert le : {{ account.createdAt | date:'dd/MM/yyyy' }}</div>
          </div>
        </div>

        <div class="empty" *ngIf="!loading && accounts.length === 0">
          Aucun compte trouvé.
        </div>
      </div>
    </div>
  `,
  styles: [`
    .container { padding: 24px; max-width: 1000px; margin: 0 auto; }
    .profile-card { background: #EBF5FB; border-radius: 8px; padding: 20px; margin-bottom: 24px; border-left: 4px solid #2E75B6; }
    .profile-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-top: 12px; }
    .badge { background: #2E75B6; color: white; padding: 2px 8px; border-radius: 12px; font-size: 12px; margin-left: 4px; }
    h2 { color: #1F4E79; margin-bottom: 16px; }
    .accounts-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 16px; }
    .account-card { background: white; border-radius: 8px; padding: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); border-top: 4px solid #2E75B6; }
    .account-header { display: flex; justify-content: space-between; margin-bottom: 8px; }
    .account-number { font-weight: bold; color: #1F4E79; }
    .currency { background: #EBF5FB; padding: 2px 8px; border-radius: 4px; font-size: 12px; }
    .balance { font-size: 24px; font-weight: bold; color: #1E7E34; margin: 8px 0; }
    .customer-name { color: #666; font-size: 14px; }
    .created-at { color: #999; font-size: 12px; margin-top: 4px; }
    .loading { color: #666; text-align: center; padding: 40px; }
    .error { color: #C0392B; background: #FDECEA; padding: 12px; border-radius: 4px; }
    .empty { text-align: center; color: #999; padding: 40px; }
  `]
})
export class AccountsComponent implements OnInit {

  accounts: BankAccount[] = [];
  profile: UserProfile | null = null;
  loading = true;
  error = '';

  constructor(
    private accountService: BankAccountService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.loadProfile();
    this.loadAccounts();
  }

  loadProfile(): void {
    this.accountService.getProfile().subscribe({
      next: (profile) => this.profile = profile,
      error: (err) => console.error('Profile error:', err)
    });
  }

  loadAccounts(): void {
    this.loading = true;
    this.accountService.getMyAccounts().subscribe({
      next: (accounts) => {
        this.accounts = accounts;
        this.loading = false;
      },
      error: (err) => {
        this.error = 'Erreur lors du chargement des comptes.';
        this.loading = false;
        console.error(err);
      }
    });
  }
}
