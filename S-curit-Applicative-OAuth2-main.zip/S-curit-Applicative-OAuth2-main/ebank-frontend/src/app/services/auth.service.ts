import { Injectable } from '@angular/core';
import { KeycloakService } from 'keycloak-angular';
import { KeycloakProfile } from 'keycloak-js';
import { from, Observable } from 'rxjs';

/**
 * Service d'authentification qui encapsule KeycloakService.
 * Fournit des méthodes simples pour l'authentification.
 */
@Injectable({ providedIn: 'root' })
export class AuthService {

  constructor(private keycloak: KeycloakService) {}

  /**
   * Vérifie si l'utilisateur est authentifié.
   */
  isLoggedIn(): boolean {
    return this.keycloak.isLoggedIn();
  }

  /**
   * Récupère le profil utilisateur Keycloak.
   */
  getUserProfile(): Observable<KeycloakProfile> {
    return from(this.keycloak.loadUserProfile());
  }

  /**
   * Récupère le nom d'utilisateur.
   */
  getUsername(): string {
    return this.keycloak.getUsername();
  }

  /**
   * Récupère les rôles de l'utilisateur.
   */
  getUserRoles(): string[] {
    return this.keycloak.getUserRoles();
  }

  /**
   * Vérifie si l'utilisateur a un rôle donné.
   */
  hasRole(role: string): boolean {
    return this.keycloak.isUserInRole(role);
  }

  /**
   * Vérifie si l'utilisateur est ADMIN.
   */
  isAdmin(): boolean {
    return this.hasRole('ADMIN');
  }

  /**
   * Récupère le token JWT brut (access token).
   */
  getToken(): Observable<string> {
    return from(this.keycloak.getToken());
  }

  /**
   * Démarre le flux de login Keycloak.
   */
  login(): void {
    this.keycloak.login();
  }

  /**
   * Déconnecte l'utilisateur et redirige vers l'accueil.
   */
  logout(): void {
    this.keycloak.logout(window.location.origin);
  }

  /**
   * Redirige vers la page de gestion du compte Keycloak.
   */
  manageAccount(): void {
    this.keycloak.getKeycloakInstance().accountManagement();
  }
}
