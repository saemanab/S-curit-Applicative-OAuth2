import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { ApiResponse, BankAccount, UserProfile } from '../models/models';

/**
 * Service Angular pour les opérations bancaires.
 * Le token JWT est ajouté automatiquement par AuthInterceptor.
 */
@Injectable({ providedIn: 'root' })
export class BankAccountService {

  private apiUrl = environment.apiUrl;

  constructor(private http: HttpClient) {}

  /**
   * Récupère les comptes de l'utilisateur connecté.
   * Requiert le rôle USER.
   */
  getMyAccounts(): Observable<BankAccount[]> {
    return this.http
      .get<ApiResponse<BankAccount[]>>(`${this.apiUrl}/accounts`)
      .pipe(map(response => response.data));
  }

  /**
   * Récupère un compte par ID.
   */
  getAccountById(id: number): Observable<BankAccount> {
    return this.http
      .get<ApiResponse<BankAccount>>(`${this.apiUrl}/accounts/${id}`)
      .pipe(map(response => response.data));
  }

  /**
   * Récupère TOUS les comptes (ADMIN uniquement).
   */
  getAllAccounts(): Observable<BankAccount[]> {
    return this.http
      .get<ApiResponse<BankAccount[]>>(`${this.apiUrl}/admin/accounts`)
      .pipe(map(response => response.data));
  }

  /**
   * Récupère le profil de l'utilisateur connecté depuis le JWT.
   */
  getProfile(): Observable<UserProfile> {
    return this.http.get<UserProfile>(`${this.apiUrl}/profile`);
  }

  /**
   * Récupère les informations du token JWT.
   */
  getTokenInfo(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/token-info`);
  }

  /**
   * Endpoint public, pas besoin de token.
   */
  getPublicInfo(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/public/info`);
  }
}
