import { NgModule, APP_INITIALIZER } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { RouterModule } from '@angular/router';

import { KeycloakAngularModule, KeycloakService } from 'keycloak-angular';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { AuthInterceptor } from './interceptors/auth.interceptor';
import { environment } from '../environments/environment';

/**
 * Initialise Keycloak avant le démarrage de l'application Angular.
 * APP_INITIALIZER bloque le bootstrap jusqu'à la résolution de la promesse.
 */
function initializeKeycloak(keycloak: KeycloakService) {
  return () =>
    keycloak.init({
      config: {
        url: environment.keycloak.url,
        realm: environment.keycloak.realm,
        clientId: environment.keycloak.clientId,
      },
      initOptions: {
        // 'check-sso' : vérifie silencieusement si l'utilisateur est déjà connecté
        // 'login-required' : redirige vers Keycloak si non connecté
        onLoad: 'check-sso',
        silentCheckSsoRedirectUri:
          window.location.origin + '/assets/silent-check-sso.html',
      },
      // Charge les rôles utilisateur depuis Keycloak
      loadUserProfileAtStartUp: true,
    });
}

@NgModule({
  declarations: [
    AppComponent,
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    RouterModule,
    AppRoutingModule,
    KeycloakAngularModule,  // Module Keycloak Angular
  ],
  providers: [
    // Initialisation Keycloak au démarrage
    {
      provide: APP_INITIALIZER,
      useFactory: initializeKeycloak,
      multi: true,
      deps: [KeycloakService],
    },
    // Intercepteur HTTP qui ajoute automatiquement le Bearer token
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true,
    },
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
