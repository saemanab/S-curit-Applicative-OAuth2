import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { KeycloakAuthGuard, KeycloakService } from 'keycloak-angular';

/**
 * Guard d'authentification basé sur Keycloak.
 *
 * Fonctionnement :
 *  1. Si l'utilisateur n'est pas authentifié → redirige vers Keycloak login
 *  2. Si l'utilisateur est authentifié mais n'a pas les rôles requis → redirige vers /unauthorized
 *  3. Sinon → accès autorisé
 */
@Injectable({ providedIn: 'root' })
export class AuthGuard extends KeycloakAuthGuard {

  constructor(
    protected override readonly router: Router,
    protected readonly keycloak: KeycloakService
  ) {
    super(router, keycloak);
  }

  public async isAccessAllowed(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Promise<boolean> {

    // Si non authentifié, rediriger vers Keycloak
    if (!this.authenticated) {
      await this.keycloak.login({
        redirectUri: window.location.origin + state.url,
      });
      return false;
    }

    // Récupérer les rôles requis depuis les data de la route
    const requiredRoles: string[] = route.data['roles'] || [];

    // Si aucun rôle requis, l'authentification seule suffit
    if (requiredRoles.length === 0) {
      return true;
    }

    // Vérifier que l'utilisateur possède tous les rôles requis
    const hasRoles = requiredRoles.every(role => this.roles.includes(role));

    if (!hasRoles) {
      this.router.navigate(['/unauthorized']);
    }

    return hasRoles;
  }
}
