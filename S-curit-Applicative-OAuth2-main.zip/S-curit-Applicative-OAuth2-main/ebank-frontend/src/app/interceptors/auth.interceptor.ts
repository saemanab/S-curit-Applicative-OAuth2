import { Injectable } from '@angular/core';
import {
  HttpInterceptor,
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpErrorResponse
} from '@angular/common/http';
import { Observable, from, throwError } from 'rxjs';
import { switchMap, catchError } from 'rxjs/operators';
import { KeycloakService } from 'keycloak-angular';
import { Router } from '@angular/router';

/**
 * Intercepteur HTTP qui ajoute automatiquement le JWT Bearer token
 * à chaque requête sortante vers l'API backend.
 *
 * Gère aussi :
 *  - Token refresh automatique si expiré
 *  - Redirection vers login si 401
 *  - Redirection vers unauthorized si 403
 */
@Injectable()
export class AuthInterceptor implements HttpInterceptor {

  constructor(
    private keycloak: KeycloakService,
    private router: Router
  ) {}

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    // Ne pas intercepter les requêtes vers Keycloak lui-même
    if (req.url.includes('localhost:8080')) {
      return next.handle(req);
    }

    return from(this.addAuthHeader(req)).pipe(
      switchMap(authReq => next.handle(authReq)),
      catchError((error: HttpErrorResponse) => this.handleError(error))
    );
  }

  private async addAuthHeader(req: HttpRequest<any>): Promise<HttpRequest<any>> {
    try {
      // Renouveler le token si expiré (updateMinValidity = 30 secondes)
      const isTokenExpired = await this.keycloak.isTokenExpired(30);

      if (isTokenExpired) {
        await this.keycloak.updateToken(30);
      }

      const token = await this.keycloak.getToken();

      return req.clone({
        setHeaders: {
          Authorization: `Bearer ${token}`
        }
      });
    } catch (error) {
      console.error('Failed to get Keycloak token:', error);
      // Token invalide → logout
      this.keycloak.logout();
      return req;
    }
  }

  private handleError(error: HttpErrorResponse): Observable<never> {
    if (error.status === 401) {
      // Token invalide ou expiré
      console.warn('401 Unauthorized - Redirecting to login');
      this.keycloak.login();
    } else if (error.status === 403) {
      // Accès refusé
      console.warn('403 Forbidden - Insufficient roles');
      this.router.navigate(['/unauthorized']);
    }
    return throwError(() => error);
  }
}
