// models/bank-account.model.ts

export interface BankAccount {
  id: number;
  accountNumber: string;
  balance: number;
  currency: string;
  createdAt: Date;
  customerName: string;
}

export interface Customer {
  id: number;
  name: string;
  email: string;
  keycloakUsername: string;
}

export interface UserProfile {
  username: string;
  email: string;
  firstName: string;
  lastName: string;
  roles: string[];
  subject: string;
  issuer: string;
}

export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data: T;
}
