import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './guards/auth.guard';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'accounts',
    pathMatch: 'full'
  },
  {
    path: 'accounts',
    loadComponent: () =>
      import('./components/accounts/accounts.component').then(m => m.AccountsComponent),
    canActivate: [AuthGuard],
    data: { roles: ['USER'] }   // Accessible par USER et ADMIN
  },
  {
    path: 'admin',
    loadComponent: () =>
      import('./components/admin/admin.component').then(m => m.AdminComponent),
    canActivate: [AuthGuard],
    data: { roles: ['ADMIN'] }  // ADMIN uniquement
  },
  {
    path: 'profile',
    loadComponent: () =>
      import('./components/accounts/accounts.component').then(m => m.AccountsComponent),
    canActivate: [AuthGuard],
    data: { roles: [] }         // Tout utilisateur authentifié
  },
  {
    path: 'unauthorized',
    loadComponent: () =>
      import('./components/login/login.component').then(m => m.LoginComponent),
  },
  {
    path: '**',
    redirectTo: 'accounts'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
