// environment.ts - Development
export const environment = {
  production: false,
  apiUrl: 'http://localhost:8085/api',
  keycloak: {
    url: 'http://localhost:8080',
    realm: 'ebank-realm',
    clientId: 'ebank-client',
  }
};
