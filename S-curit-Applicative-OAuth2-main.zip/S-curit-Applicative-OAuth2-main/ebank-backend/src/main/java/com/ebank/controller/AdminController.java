package com.ebank.controller;

import com.ebank.dto.Dtos;
import com.ebank.service.BankAccountService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Endpoints réservés aux ADMIN uniquement.
 * Toutes les méthodes sont protégées par @PreAuthorize("hasRole('ADMIN')").
 */
@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasRole('ADMIN')")   // Appliqué à toute la classe
@RequiredArgsConstructor
@Slf4j
public class AdminController {

    private final BankAccountService bankAccountService;

    /**
     * GET /api/admin/accounts
     * Retourne TOUS les comptes de TOUS les clients.
     */
    @GetMapping("/accounts")
    public ResponseEntity<Dtos.ApiResponse<List<Dtos.BankAccountDto>>> getAllAccounts(
            @AuthenticationPrincipal Jwt jwt) {

        log.info("Admin '{}' requesting all accounts", jwt.getClaimAsString("preferred_username"));
        List<Dtos.BankAccountDto> accounts = bankAccountService.getAllAccounts();
        return ResponseEntity.ok(Dtos.ApiResponse.ok(accounts));
    }

    /**
     * GET /api/admin/dashboard
     * Tableau de bord admin.
     */
    @GetMapping("/dashboard")
    public ResponseEntity<Object> dashboard(@AuthenticationPrincipal Jwt jwt) {
        return ResponseEntity.ok(java.util.Map.of(
            "adminUser", jwt.getClaimAsString("preferred_username"),
            "message", "Bienvenue dans le panneau d'administration E-Bank",
            "totalAccounts", bankAccountService.getAllAccounts().size()
        ));
    }
}
