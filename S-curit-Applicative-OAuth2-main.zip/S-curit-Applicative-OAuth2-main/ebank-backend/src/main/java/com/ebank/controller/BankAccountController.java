package com.ebank.controller;

import com.ebank.dto.Dtos;
import com.ebank.service.BankAccountService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Controller principal des comptes bancaires.
 *
 * Démontre la sécurité avec Keycloak :
 *  - @PreAuthorize pour les règles par méthode
 *  - Extraction des claims JWT (@AuthenticationPrincipal Jwt)
 *  - Vérification des rôles programmatique
 */
@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
@Slf4j
public class BankAccountController {

    private final BankAccountService bankAccountService;

    /**
     * GET /api/accounts
     * Retourne les comptes de l'utilisateur connecté.
     * Accessible par les rôles USER et ADMIN.
     */
    @GetMapping("/accounts")
    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    public ResponseEntity<Dtos.ApiResponse<List<Dtos.BankAccountDto>>> getMyAccounts(
            @org.springframework.security.core.annotation.AuthenticationPrincipal Jwt jwt) {

        // Extraire le username depuis le JWT Keycloak
        String username = jwt.getClaimAsString("preferred_username");
        log.info("User '{}' requesting their accounts", username);

        List<Dtos.BankAccountDto> accounts = bankAccountService.getAccountsByUsername(username);
        return ResponseEntity.ok(Dtos.ApiResponse.ok(accounts));
    }

    /**
     * GET /api/accounts/{id}
     * Retourne un compte par ID.
     * L'utilisateur ne peut accéder qu'à ses propres comptes, sauf ADMIN.
     */
    @GetMapping("/accounts/{id}")
    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    public ResponseEntity<Dtos.ApiResponse<Dtos.BankAccountDto>> getAccountById(
            @PathVariable Long id,
            @org.springframework.security.core.annotation.AuthenticationPrincipal Jwt jwt,
            Authentication auth) {

        String username = jwt.getClaimAsString("preferred_username");
        boolean isAdmin = auth.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));

        Dtos.BankAccountDto account = bankAccountService.getAccountById(id, username, isAdmin);
        return ResponseEntity.ok(Dtos.ApiResponse.ok(account));
    }

    /**
     * GET /api/profile
     * Retourne le profil de l'utilisateur connecté extrait du JWT.
     */
    @GetMapping("/profile")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<Dtos.UserProfileDto> getProfile(
            @org.springframework.security.core.annotation.AuthenticationPrincipal Jwt jwt,
            Authentication auth) {

        // Extraire les rôles depuis les authorities Spring Security
        List<String> roles = auth.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .filter(a -> a.startsWith("ROLE_"))
                .map(a -> a.replace("ROLE_", ""))
                .collect(Collectors.toList());

        Dtos.UserProfileDto profile = Dtos.UserProfileDto.builder()
                .username(jwt.getClaimAsString("preferred_username"))
                .email(jwt.getClaimAsString("email"))
                .firstName(jwt.getClaimAsString("given_name"))
                .lastName(jwt.getClaimAsString("family_name"))
                .subject(jwt.getSubject())
                .issuer(jwt.getIssuer() != null ? jwt.getIssuer().toString() : null)
                .roles(roles)
                .build();

        log.info("Profile request for user: {}", profile.getUsername());
        return ResponseEntity.ok(profile);
    }

    /**
     * GET /api/token-info
     * Affiche le contenu complet du JWT (utile pour le débogage).
     */
    @GetMapping("/token-info")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<Map<String, Object>> getTokenInfo(
            @org.springframework.security.core.annotation.AuthenticationPrincipal Jwt jwt) {

        return ResponseEntity.ok(Map.of(
            "subject",   jwt.getSubject(),
            "issuer",    jwt.getIssuer() != null ? jwt.getIssuer().toString() : "",
            "issuedAt",  jwt.getIssuedAt() != null ? jwt.getIssuedAt().toString() : "",
            "expiresAt", jwt.getExpiresAt() != null ? jwt.getExpiresAt().toString() : "",
            "claims",    jwt.getClaims()
        ));
    }
}
