package com.ebank.repository;

import com.ebank.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {

    Optional<Customer> findByKeycloakUsername(String keycloakUsername);

    Optional<Customer> findByEmail(String email);
}
