package com.ebank.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

/**
 * DTOs (Data Transfer Objects) pour les réponses API.
 * Evitent d'exposer les entités JPA directement.
 */
public class Dtos {

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class CustomerDto {
        private Long id;
        private String name;
        private String email;
        private String keycloakUsername;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class BankAccountDto {
        private Long id;
        private String accountNumber;
        private Double balance;
        private String currency;
        private Date createdAt;
        private String customerName;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class UserProfileDto {
        private String username;
        private String email;
        private String firstName;
        private String lastName;
        private List<String> roles;
        private String subject;
        private String issuer;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class ApiResponse<T> {
        private boolean success;
        private String message;
        private T data;

        public static <T> ApiResponse<T> ok(T data) {
            return ApiResponse.<T>builder()
                    .success(true)
                    .message("OK")
                    .data(data)
                    .build();
        }

        public static <T> ApiResponse<T> error(String message) {
            return ApiResponse.<T>builder()
                    .success(false)
                    .message(message)
                    .build();
        }
    }
}
