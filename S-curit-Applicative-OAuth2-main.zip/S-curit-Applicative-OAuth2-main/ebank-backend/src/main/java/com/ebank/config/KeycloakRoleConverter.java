package com.ebank.config;

import org.springframework.core.convert.converter.Converter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Convertisseur de rôles Keycloak vers Spring Security GrantedAuthorities.
 *
 * Les rôles Keycloak sont stockés dans le claim JWT :
 * {
 *   "realm_access": {
 *     "roles": ["USER", "ADMIN", "offline_access", ...]
 *   }
 * }
 *
 * Spring Security attend des rôles avec le préfixe "ROLE_" pour que
 * hasRole('USER') fonctionne (qui recherche "ROLE_USER").
 */
public class KeycloakRoleConverter implements Converter<Jwt, Collection<GrantedAuthority>> {

    private static final String REALM_ACCESS_CLAIM = "realm_access";
    private static final String ROLES_CLAIM = "roles";
    private static final String ROLE_PREFIX = "ROLE_";

    @Override
    public Collection<GrantedAuthority> convert(Jwt jwt) {
        Collection<GrantedAuthority> authorities = new ArrayList<>();

        // Extraire les rôles du realm (realm_access.roles)
        authorities.addAll(extractRealmRoles(jwt));

        // Extraire les rôles du client (resource_access.<clientId>.roles) - optionnel
        authorities.addAll(extractClientRoles(jwt));

        return authorities;
    }

    /**
     * Extrait les rôles du realm depuis le claim "realm_access".
     */
    @SuppressWarnings("unchecked")
    private List<GrantedAuthority> extractRealmRoles(Jwt jwt) {
        Map<String, Object> realmAccess = jwt.getClaim(REALM_ACCESS_CLAIM);

        if (realmAccess == null || !realmAccess.containsKey(ROLES_CLAIM)) {
            return List.of();
        }

        List<String> roles = (List<String>) realmAccess.get(ROLES_CLAIM);

        return roles.stream()
                .map(role -> new SimpleGrantedAuthority(ROLE_PREFIX + role))
                .collect(Collectors.toList());
    }

    /**
     * Extrait les rôles spécifiques au client depuis "resource_access.<clientId>.roles".
     * Utile si vous gérez des rôles au niveau client plutôt que realm.
     */
    @SuppressWarnings("unchecked")
    private List<GrantedAuthority> extractClientRoles(Jwt jwt) {
        Map<String, Object> resourceAccess = jwt.getClaim("resource_access");

        if (resourceAccess == null) {
            return List.of();
        }

        // Récupérer les rôles du client "ebank-client"
        Map<String, Object> clientAccess =
                (Map<String, Object>) resourceAccess.get("ebank-client");

        if (clientAccess == null || !clientAccess.containsKey(ROLES_CLAIM)) {
            return List.of();
        }

        List<String> clientRoles = (List<String>) clientAccess.get(ROLES_CLAIM);

        return clientRoles.stream()
                .map(role -> new SimpleGrantedAuthority(ROLE_PREFIX + role))
                .collect(Collectors.toList());
    }
}
