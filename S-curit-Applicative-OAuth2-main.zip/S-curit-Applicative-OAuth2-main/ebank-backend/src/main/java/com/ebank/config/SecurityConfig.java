package com.ebank.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.Arrays;
import java.util.List;

/**
 * Configuration principale de Spring Security avec Keycloak JWT.
 *
 * Ce Resource Server valide les tokens JWT émis par Keycloak
 * en vérifiant leur signature via les clés publiques JWKS.
 */
@Configuration
@EnableWebSecurity
@EnableMethodSecurity(prePostEnabled = true)  // Active @PreAuthorize, @PostAuthorize
public class SecurityConfig {

    @Value("${app.cors.allowed-origins}")
    private String allowedOrigins;

    /**
     * Chaîne de filtres de sécurité principale.
     */
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            // Désactiver CSRF (API REST stateless)
            .csrf(AbstractHttpConfigurer::disable)

            // Configurer CORS
            .cors(cors -> cors.configurationSource(corsConfigurationSource()))

            // Stateless : pas de session HTTP
            .sessionManagement(session ->
                session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))

            // Règles d'autorisation par URL
            .authorizeHttpRequests(auth -> auth
                // Endpoints publics
                .requestMatchers("/api/public/**").permitAll()
                // Console H2 (dev uniquement)
                .requestMatchers("/h2-console/**").permitAll()
                // Endpoints admin uniquement
                .requestMatchers("/api/admin/**").hasRole("ADMIN")
                // Endpoints utilisateurs authentifiés
                .requestMatchers("/api/user/**").hasAnyRole("USER", "ADMIN")
                // Tout le reste nécessite une authentification
                .anyRequest().authenticated()
            )

            // Configurer le Resource Server JWT
            .oauth2ResourceServer(oauth2 -> oauth2
                .jwt(jwt -> jwt.jwtAuthenticationConverter(jwtAuthenticationConverter()))
            )

            // Désactiver les headers X-Frame-Options pour H2 console
            .headers(headers -> headers.frameOptions(frame -> frame.disable()));

        return http.build();
    }

    /**
     * Convertit les rôles Keycloak (realm_access.roles) en GrantedAuthorities Spring Security.
     *
     * Sans ce converter, Spring ne reconnait pas les rôles Keycloak car ils sont
     * dans un claim imbriqué (realm_access.roles) et non dans "scope".
     */
    @Bean
    public JwtAuthenticationConverter jwtAuthenticationConverter() {
        JwtAuthenticationConverter converter = new JwtAuthenticationConverter();
        converter.setJwtGrantedAuthoritiesConverter(new KeycloakRoleConverter());
        return converter;
    }

    /**
     * Configuration CORS pour autoriser les requêtes depuis Angular (localhost:4200).
     */
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowedOrigins(List.of(allowedOrigins.split(",")));
        config.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"));
        config.setAllowedHeaders(Arrays.asList("Authorization", "Content-Type", "Accept"));
        config.setAllowCredentials(true);
        config.setMaxAge(3600L);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);
        return source;
    }
}
