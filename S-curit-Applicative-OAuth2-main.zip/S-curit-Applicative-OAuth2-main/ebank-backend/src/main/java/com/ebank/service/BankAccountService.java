package com.ebank.service;

import com.ebank.dto.Dtos;
import com.ebank.entity.BankAccount;
import com.ebank.entity.Customer;
import com.ebank.repository.BankAccountRepository;
import com.ebank.repository.CustomerRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
@RequiredArgsConstructor
@Slf4j
public class BankAccountService {

    private final BankAccountRepository accountRepository;
    private final CustomerRepository customerRepository;

    /**
     * Récupère tous les comptes d'un utilisateur identifié par son username Keycloak.
     */
    public List<Dtos.BankAccountDto> getAccountsByUsername(String keycloakUsername) {
        log.debug("Fetching accounts for user: {}", keycloakUsername);
        return accountRepository.findByCustomerKeycloakUsername(keycloakUsername)
                .stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    /**
     * Récupère tous les comptes (admin only).
     */
    public List<Dtos.BankAccountDto> getAllAccounts() {
        log.debug("Fetching all accounts (admin)");
        return accountRepository.findAll()
                .stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    /**
     * Récupère un compte par ID (vérifie que l'utilisateur est propriétaire).
     */
    public Dtos.BankAccountDto getAccountById(Long id, String keycloakUsername, boolean isAdmin) {
        BankAccount account = accountRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Compte introuvable: " + id));

        // Vérification d'accès : l'utilisateur ne peut voir que ses propres comptes
        if (!isAdmin && !account.getCustomer().getKeycloakUsername().equals(keycloakUsername)) {
            throw new SecurityException("Accès refusé au compte: " + id);
        }

        return toDto(account);
    }

    /**
     * Récupère le profil du customer lié à un username Keycloak.
     */
    public Dtos.CustomerDto getCustomerByUsername(String keycloakUsername) {
        Customer customer = customerRepository.findByKeycloakUsername(keycloakUsername)
                .orElseThrow(() -> new RuntimeException("Customer introuvable: " + keycloakUsername));
        return Dtos.CustomerDto.builder()
                .id(customer.getId())
                .name(customer.getName())
                .email(customer.getEmail())
                .keycloakUsername(customer.getKeycloakUsername())
                .build();
    }

    private Dtos.BankAccountDto toDto(BankAccount account) {
        return Dtos.BankAccountDto.builder()
                .id(account.getId())
                .accountNumber(account.getAccountNumber())
                .balance(account.getBalance())
                .currency(account.getCurrency())
                .createdAt(account.getCreatedAt())
                .customerName(account.getCustomer().getName())
                .build();
    }
}
