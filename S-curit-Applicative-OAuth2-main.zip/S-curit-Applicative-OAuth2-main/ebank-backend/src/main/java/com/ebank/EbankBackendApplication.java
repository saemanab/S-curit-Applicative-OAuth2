package com.ebank;

import com.ebank.entity.BankAccount;
import com.ebank.entity.Customer;
import com.ebank.repository.BankAccountRepository;
import com.ebank.repository.CustomerRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.Date;

@SpringBootApplication
public class EbankBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(EbankBackendApplication.class, args);
    }

    /**
     * Initialise la base de données H2 avec des données de test.
     */
    @Bean
    CommandLineRunner initData(CustomerRepository customerRepo,
                               BankAccountRepository accountRepo) {
        return args -> {
            // Créer des customers de test
            Customer c1 = customerRepo.save(Customer.builder()
                    .name("Mohamed Ali")
                    .email("user1@ebank.com")
                    .keycloakUsername("user1")
                    .build());

            Customer c2 = customerRepo.save(Customer.builder()
                    .name("Fatima Zahra")
                    .email("admin1@ebank.com")
                    .keycloakUsername("admin1")
                    .build());

            // Créer des comptes bancaires
            accountRepo.save(BankAccount.builder()
                    .accountNumber("ACC-001")
                    .balance(15000.00)
                    .currency("MAD")
                    .createdAt(new Date())
                    .customer(c1)
                    .build());

            accountRepo.save(BankAccount.builder()
                    .accountNumber("ACC-002")
                    .balance(32500.50)
                    .currency("MAD")
                    .createdAt(new Date())
                    .customer(c1)
                    .build());

            accountRepo.save(BankAccount.builder()
                    .accountNumber("ACC-003")
                    .balance(8900.75)
                    .currency("EUR")
                    .createdAt(new Date())
                    .customer(c2)
                    .build());

            System.out.println("✅ Base de données initialisée avec succès !");
        };
    }
}
