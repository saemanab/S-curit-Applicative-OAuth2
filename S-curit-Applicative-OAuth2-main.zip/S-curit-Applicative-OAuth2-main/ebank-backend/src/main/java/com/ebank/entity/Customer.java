package com.ebank.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.List;

@Entity
@Table(name = "customers")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false, unique = true)
    private String email;

    /**
     * Correspond au "preferred_username" dans le JWT Keycloak.
     * Utilisé pour lier un Customer à un utilisateur Keycloak.
     */
    @Column(name = "keycloak_username", nullable = false, unique = true)
    private String keycloakUsername;

    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @ToString.Exclude
    private List<BankAccount> accounts;
}
